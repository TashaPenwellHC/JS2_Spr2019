var app = new Vue({
  el: '#app',
  data: {
    hi: "",
    isTrue: true,
    hello: "Hello World"
  }
});