A Pen created at CodePen.io. You can find this one at https://codepen.io/stolinski/pen/a9657014bc9c3ad55a9b51191fbf0aa8.

 