var app = new Vue({
  el: '#app',
  data: {
    hello: "Hello World"
  }
});