A Pen created at CodePen.io. You can find this one at https://codepen.io/stolinski/pen/18417cb1bdddd8001762d1c81ea9c811.

 