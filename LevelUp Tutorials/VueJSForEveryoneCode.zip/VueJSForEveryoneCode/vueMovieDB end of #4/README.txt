A Pen created at CodePen.io. You can find this one at https://codepen.io/stolinski/pen/d39bdd3bcbfa1eb82da9cef9aa69d797.

 