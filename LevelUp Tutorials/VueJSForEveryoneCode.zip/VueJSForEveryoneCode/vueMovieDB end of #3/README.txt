A Pen created at CodePen.io. You can find this one at https://codepen.io/stolinski/pen/ebb9b6ec7d2ca8dd92bd63403e1f2d89.

 