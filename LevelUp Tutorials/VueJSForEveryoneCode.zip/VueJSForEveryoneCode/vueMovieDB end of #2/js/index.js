var app = new Vue({
  el: '#app',
  data: {
    isTrue: false,
    hello: "Hello World"
  }
});