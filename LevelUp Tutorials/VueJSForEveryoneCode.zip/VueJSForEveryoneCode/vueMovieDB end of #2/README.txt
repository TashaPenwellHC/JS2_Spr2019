A Pen created at CodePen.io. You can find this one at https://codepen.io/stolinski/pen/131266202aeab1e5d3b65f4e30179639.

 